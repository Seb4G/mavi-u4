#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>
using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Juego del Ca�on con Ragdoll");
    Event evt;
    b2Vec2 gravity(0.0f, 4.0f);
    b2World world(gravity);

    b2BodyDef pisoBodyDef;
    pisoBodyDef.position.Set(0.0f, 0.0f);
    b2Body* pisoBody;
    pisoBodyDef.position.Set(400.0f, 600.0f);
    pisoBody = world.CreateBody(&pisoBodyDef);
    b2PolygonShape pisoBox;
    pisoBox.SetAsBox(400.0f, 10.0f);
    pisoBody->CreateFixture(&pisoBox, 0.0f);
    pisoBodyDef.position.Set(-10.0f, 300.0f);
    pisoBody = world.CreateBody(&pisoBodyDef);
    pisoBox.SetAsBox(10.0f, 300.0f);
    pisoBody->CreateFixture(&pisoBox, 0.0f);
    pisoBodyDef.position.Set(810.0f, 300.0f);
    pisoBody = world.CreateBody(&pisoBodyDef);
    pisoBox.SetAsBox(10.0f, 300.0f);
    pisoBody->CreateFixture(&pisoBox, 0.0f);
    pisoBodyDef.position.Set(400.0f, -10.0f);
    pisoBody = world.CreateBody(&pisoBodyDef);
    pisoBox.SetAsBox(400.0f, 10.0f);
    pisoBody->CreateFixture(&pisoBox, 0.0f);
    pisoBodyDef.position.Set(400.0f, 610.0f);
    pisoBody = world.CreateBody(&pisoBodyDef);
    pisoBox.SetAsBox(400.0f, 10.0f);
    pisoBody->CreateFixture(&pisoBox, 0.0f);

    b2BodyDef ca�onBodyDef;
    ca�onBodyDef.type = b2_staticBody;
    ca�onBodyDef.position.Set(40.0f, 500.0f);
    b2Body* ca�onBody = world.CreateBody(&ca�onBodyDef);
    b2PolygonShape ca�onShape;
    ca�onShape.SetAsBox(10.0f, 20.0f);
    b2FixtureDef ca�onFixtureDef;
    ca�onFixtureDef.shape = &ca�onShape;
    ca�onFixtureDef.density = 1.0f;
    ca�onBody->CreateFixture(&ca�onFixtureDef);

    b2BodyDef obstaculo1BodyDef;
    obstaculo1BodyDef.type = b2_dynamicBody;
    obstaculo1BodyDef.position.Set(500.0f, 575.0f);
    b2Body* obstaculo1Body = world.CreateBody(&obstaculo1BodyDef);
    b2PolygonShape obstaculo1Shape;
    obstaculo1Shape.SetAsBox(25.0f, 25.0f);
    b2FixtureDef obstaculo1FixtureDef;
    obstaculo1FixtureDef.shape = &obstaculo1Shape;
    obstaculo1FixtureDef.density = 1.5f;
    obstaculo1FixtureDef.friction = 0.3f;
    obstaculo1Body->CreateFixture(&obstaculo1FixtureDef);

    b2BodyDef obstaculo2BodyDef;
    obstaculo2BodyDef.type = b2_staticBody;
    obstaculo2BodyDef.position.Set(700.0f, 300.0f);
    b2Body* obstaculo2Body = world.CreateBody(&obstaculo2BodyDef);
    b2PolygonShape obstaculo2Shape;
    obstaculo2Shape.SetAsBox(25.0f, 25.0f);
    b2FixtureDef obstaculo2FixtureDef;
    obstaculo2FixtureDef.shape = &obstaculo2Shape;
    obstaculo2FixtureDef.density = 0.0f;
    obstaculo2FixtureDef.friction = 0.3f;
    obstaculo2Body->CreateFixture(&obstaculo2FixtureDef);
    std::vector<std::vector<b2Body*>> ragdolls;

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed) {
                App.close();
            }
            if (evt.type == Event::MouseButtonPressed && evt.mouseButton.button == Mouse::Left) {
                std::vector<b2Body*> ragdollBodies;
                b2Body* torsoBody = nullptr;
                b2Body* cabezaBody = nullptr;
                b2Body* brazoIzqBody = nullptr;
                b2Body* brazoDerBody = nullptr;
                b2Body* piernaIzqBody = nullptr;
                b2Body* piernaDerBody = nullptr;

                Vector2i mousePos = Mouse::getPosition(App);
                Vector2f cannonPos = Vector2f(40.0f, 500.0f);
                b2Vec2 force((mousePos.x - cannonPos.x) * 10000.0f, (mousePos.y - cannonPos.y) * 10000.0f);

                b2BodyDef torsoBodyDef;
                torsoBodyDef.type = b2_dynamicBody;
                torsoBodyDef.position.Set(65.0f, 500.0f);
                torsoBody = world.CreateBody(&torsoBodyDef);
                b2PolygonShape torsoShape;
                torsoShape.SetAsBox(15.0f, 25.0f);
                b2FixtureDef torsoFixtureDef;
                torsoFixtureDef.shape = &torsoShape;
                torsoFixtureDef.density = 3.0f;
                torsoFixtureDef.friction = 0.5f;
                torsoBody->CreateFixture(&torsoFixtureDef);

                b2BodyDef cabezaBodyDef;
                cabezaBodyDef.type = b2_dynamicBody;
                cabezaBodyDef.position.Set(65.0f, 460.0f);
                cabezaBody = world.CreateBody(&cabezaBodyDef);
                b2PolygonShape cabezaShape;
                cabezaShape.SetAsBox(10.0f, 10.0f);
                b2FixtureDef cabezaFixtureDef;
                cabezaFixtureDef.shape = &cabezaShape;
                cabezaFixtureDef.density = 0.5f;
                cabezaBody->CreateFixture(&cabezaFixtureDef);
                b2RevoluteJointDef cuelloJointDef;
                cuelloJointDef.Initialize(torsoBody, cabezaBody, b2Vec2(65.0f, 465.0f));
                cuelloJointDef.collideConnected = false;
                world.CreateJoint(&cuelloJointDef);

                b2BodyDef brazoIzqBodyDef;
                brazoIzqBodyDef.type = b2_dynamicBody;
                brazoIzqBodyDef.position.Set(55.0f, 500.0f);
                brazoIzqBody = world.CreateBody(&brazoIzqBodyDef);
                b2PolygonShape brazoIzqShape;
                brazoIzqShape.SetAsBox(5.0f, 40.0f);
                b2FixtureDef brazoIzqFixtureDef;
                brazoIzqFixtureDef.shape = &brazoIzqShape;
                brazoIzqFixtureDef.density = 0.5f;
                brazoIzqBody->CreateFixture(&brazoIzqFixtureDef);
                b2RevoluteJointDef JointIzqDef;
                JointIzqDef.Initialize(torsoBody, brazoIzqBody, b2Vec2(60.0f, 490.0f));
                JointIzqDef.collideConnected = false;
                world.CreateJoint(&JointIzqDef);

                b2BodyDef brazoDerBodyDef;
                brazoDerBodyDef.type = b2_dynamicBody;
                brazoDerBodyDef.position.Set(95.0f, 500.0f);
                brazoDerBody = world.CreateBody(&brazoDerBodyDef);
                b2PolygonShape brazoDerShape;
                brazoDerShape.SetAsBox(5.0f, 40.0f);
                b2FixtureDef brazoDerFixtureDef;
                brazoDerFixtureDef.shape = &brazoDerShape;
                brazoDerFixtureDef.density = 0.5f;
                brazoDerBody->CreateFixture(&brazoDerFixtureDef);
                b2RevoluteJointDef JointDerDef;
                JointDerDef.Initialize(torsoBody, brazoDerBody, b2Vec2(90.0f, 490.0f));
                JointDerDef.collideConnected = false;
                world.CreateJoint(&JointDerDef);

                b2BodyDef piernaIzqBodyDef;
                piernaIzqBodyDef.type = b2_dynamicBody;
                piernaIzqBodyDef.position.Set(55.0f, 540.0f);
                piernaIzqBody = world.CreateBody(&piernaIzqBodyDef);
                b2PolygonShape piernaIzqShape;
                piernaIzqShape.SetAsBox(5.0f, 15.0f);
                b2FixtureDef piernaIzqFixtureDef;
                piernaIzqFixtureDef.shape = &piernaIzqShape;
                piernaIzqFixtureDef.density = 2.5f;
                piernaIzqBody->CreateFixture(&piernaIzqFixtureDef);
                b2RevoluteJointDef piernaIzqJointDef;
                piernaIzqJointDef.Initialize(torsoBody, piernaIzqBody, b2Vec2(55.0f, 500.0f));
                piernaIzqJointDef.collideConnected = false;
                world.CreateJoint(&piernaIzqJointDef);

                b2BodyDef piernaDerBodyDef;
                piernaDerBodyDef.type = b2_dynamicBody;
                piernaDerBodyDef.position.Set(70.0f, 540.0f);
                piernaDerBody = world.CreateBody(&piernaDerBodyDef);
                b2PolygonShape piernaDerShape;
                piernaDerShape.SetAsBox(5.0f, 15.0f);
                b2FixtureDef piernaDerFixtureDef;
                piernaDerFixtureDef.shape = &piernaDerShape;
                piernaDerFixtureDef.density = 2.5f;
                piernaDerBody->CreateFixture(&piernaDerFixtureDef);
                b2RevoluteJointDef piernaDerJointDef;
                piernaDerJointDef.Initialize(torsoBody, piernaDerBody, b2Vec2(70.0f, 500.0f));
                piernaDerJointDef.collideConnected = false;
                world.CreateJoint(&piernaDerJointDef);

                ragdollBodies.push_back(torsoBody);
                ragdollBodies.push_back(cabezaBody);
                ragdollBodies.push_back(brazoIzqBody);
                ragdollBodies.push_back(brazoDerBody);
                ragdollBodies.push_back(piernaIzqBody);
                ragdollBodies.push_back(piernaDerBody);
                ragdolls.push_back(ragdollBodies);
                torsoBody->ApplyLinearImpulseToCenter(force, true);
            }
        }
        world.Step(1/60.0f, 10, 10);
        App.clear();

        RectangleShape ca�on(Vector2f(30, 20));
        ca�on.setFillColor(Color::Green);
        ca�on.setOrigin(5, 10);
        ca�on.setPosition(40.0f, 500.0f);
        App.draw(ca�on);

        Vector2i mousePos = Mouse::getPosition(App);
        VertexArray linea(Lines, 2);
        linea[0].position = Vector2f(65.0f, 500.0f);
        linea[1].position = Vector2f(mousePos.x, mousePos.y);
        linea[0].color = Color::Red;
        linea[1].color = Color::Red;
        App.draw(linea);

        RectangleShape piso(Vector2f(800, 10));
        piso.setPosition(0, 590);
        App.draw(piso);

        RectangleShape obstaculo2(Vector2f(50, 50));
        obstaculo2.setFillColor(Color::Red);
        obstaculo2.setOrigin(25, 25);
        obstaculo2.setPosition(700.0f, 300.0f);
        App.draw(obstaculo2);

        RectangleShape obstaculo1(Vector2f(50, 50));
        obstaculo1.setFillColor(Color::Red);
        obstaculo1.setOrigin(25, 25);
        obstaculo1.setPosition(obstaculo1Body->GetPosition().x, obstaculo1Body->GetPosition().y);
        obstaculo1.setRotation(obstaculo1Body->GetAngle() * 180 / b2_pi);
        App.draw(obstaculo1);

        for (const auto& ragdoll : ragdolls) {
            for (int i = 0; i < ragdoll.size(); ++i) {
                if (ragdoll[i] != nullptr) {
                    RectangleShape partes;
                    Vector2f size;
                    Color color;
                    if (i == 0) {
                        size = Vector2f(30, 50);
                        color = Color::Blue;
                    }
                    else if (i == 1) {
                        size = Vector2f(20, 20);
                        color = Color::Green;
                    }
                    else {
                        size = Vector2f(10, 40);
                        color = Color::Green;
                    }
                    partes.setSize(size);
                    partes.setOrigin(size.x / 2, size.y / 2);
                    partes.setPosition(ragdoll[i]->GetPosition().x, ragdoll[i]->GetPosition().y);
                    partes.setRotation(ragdoll[i]->GetAngle() * 180 / b2_pi);
                    partes.setFillColor(color);
                    App.draw(partes);
                }
            }
        }
        App.display();
    }
    return 0;
}